<?php
    define("DB_HOST", "localhost");
    define("DB_USER", "id20107267_stiller");
    define("DB_PASSWORD", "KQshB*|_gVu7e<])");
    define("DB_NAME", "id20107267_apex");
?>