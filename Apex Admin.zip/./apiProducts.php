<?php
header('Content-Type: application/json; charset=utf-8');
require_once 'db_connect.php';
define('UPLOAD_PATH', 'images/products/');
$response = array();

if (isset($_GET['apicall'])) {

    switch ($_GET['apicall']) {

        case 'createProduct':
            if (isTheseParametersAvailable(array('productName', 'productType', 'productPrice', 'productCondition', 'productManufacter', 'productWeight', 'productColor', 'productStock', 'productDescription')) && isset($_FILES['productImage']['name'])) {
                $productName = $_POST['productName'];
                $productType = $_POST['productType'];
                $productImage = $_FILES['productImage']['name'];
                $productPrice = $_POST['productPrice'];
                $productCondition = $_POST['productCondition'];
                $productManufacter = $_POST['productManufacter'];
                $productWeight = $_POST['productWeight'];
                $productColor = $_POST['productColor'];
                $productStock = $_POST['productStock'];
                $productDescription = $_POST['productDescription'];

                try {
                    compressImage($_FILES['productImage']['tmp_name'], UPLOAD_PATH . $productImage, 8);

                    $stmt = $con->prepare("INSERT INTO products (productName, productType, productImage, productPrice, productCondition, productManufacter, productWeight, productColor, productStock, productDescription) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                    $stmt->bind_param("sssdssssis", $productName, $productType, $productImage, $productPrice, $productCondition, $productManufacter, $productWeight, $productColor, $productStock, $productDescription);
                    if ($stmt->execute()) {
                        $response['error'] = false;
                        $response['message'] = 'Product added successfully';
                    } else {
                        throw new Exception("Something went wrong");
                    }
                } catch (Exception $e) {
                    $response['error'] = true;
                    $response['message'] = 'Something went wrong';
                }
            } else {
                $response['error'] = true;
                $response['message'] = 'Required parameters are not insufficient';
                $response['counter'] = $i;
            }

            break;

        case 'readProduct':
            $host = 'https://apex-admin.000webhostapp.com/';

            $stmt1 = $con->prepare("SELECT * FROM products");
            $stmt1->execute();
            $result = $stmt1->get_result()->fetch_all(MYSQLI_ASSOC);

            if (!$result) {
                $response['error'] = false;
                $response['message'] = 'Table is empty';
                $stmt1->close();
            } else {
                $stmt = $con->prepare("SELECT productId, productName, productType, productImage, productPrice, productCondition, productManufacter, productWeight, productColor, productStock, productDescription FROM products");
                $stmt->bind_result($productId, $productName, $productType, $productImage, $productPrice, $productCondition, $productManufacter, $productWeight, $productColor, $productStock, $productDescription);
                $stmt->execute();


                $products = array();
                while ($stmt->fetch()) {
                    $temp = array();
                    $temp['productId'] = $productId;
                    $temp['productName'] = $productName;
                    $temp['productType'] = $productType;
                    $temp['productImage'] = $host . UPLOAD_PATH . $productImage;
                    $temp['productPrice'] = $productPrice;
                    $temp['productCondition'] = $productCondition;
                    $temp['productManufacter'] = $productManufacter;
                    $temp['productWeight'] = $productWeight;
                    $temp['productColor'] = $productColor;
                    $temp['productStock'] = $productStock;
                    $temp['productDescription'] = $productDescription;
                    array_push($products, $temp);
                }
                $response['products'] = $products;
            }
            break;

        case 'updateProduct':

            if (
                isTheseParametersAvailable(array('productId', 'productName', 'productType', 'productPrice', 'productCondition', 'productManufacter', 'productWeight', 'productColor', 'productStock', 'productDescription'))
                && isset($_FILES['productImage']['name'])
            ) {
                $productId = $_POST['productId'];
                $productName = $_POST['productName'];
                $productType = $_POST['productType'];
                $productImage = $_FILES['productImage']['name'];
                $productPrice = $_POST['productPrice'];
                $productCondition = $_POST['productCondition'];
                $productManufacter = $_POST['productManufacter'];
                $productWeight = $_POST['productWeight'];
                $productColor = $_POST['productColor'];
                $productStock = $_POST['productStock'];
                $productDescription = $_POST['productDescription'];

                if (!$productImage == "") {
                    $stmt1 = $con->prepare("SELECT productImage FROM products WHERE productId = ?");
                    $stmt1->bind_param("i", $productId);
                    $stmt1->execute();
                    $result = $stmt1->get_result();
                    while ($row = $result->fetch_assoc()) {
                        unlink(UPLOAD_PATH . $row['productImage']);
                    }
                    compressImage($_FILES['productImage']['tmp_name'], UPLOAD_PATH . $productImage, 8);

                    $stmt = $con->prepare("UPDATE products SET productName = ?, productType = ?, productImage = ?, productPrice = ?, productCondition = ?, productManufacter = ?, productWeight = ?, productColor = ?, productStock = ?, productDescription = ? WHERE productId = ?");
                    $stmt->bind_param("sssdssssisi", $productName, $productType, $productImage, $productPrice, $productCondition, $productManufacter, $productWeight, $productColor, $productStock, $productDescription, $productId);
                } else {
                    $stmt = $con->prepare("UPDATE products SET productName = ?, productType = ?, productPrice = ?, productCondition = ?, productManufacter = ?, productWeight = ?, productColor = ?, productStock = ?, productDescription = ? WHERE productId = ?");
                    $stmt->bind_param("ssdssssisi", $productName, $productType, $productPrice, $productCondition, $productManufacter, $productWeight, $productColor, $productStock, $productDescription, $productId);
                }



                if ($stmt->execute()) {
                    $response['error'] = false;
                    $response['message'] = 'Product updated successfully';
                } else {
                    $response['error'] = true;
                    $response['message'] = $stmt->error;
                }
            } else {
                $response['error'] = true;
                $response['message'] = 'required parameters are not insufficient';
            }
            break;

        case 'deleteProduct':
            if (isTheseParametersAvailable(array('productId'))) {
                $productId = $_POST['productId'];

                $stmt = $con->prepare("DELETE FROM products WHERE productId = ?");
                $stmt->bind_param("i", $productId);

                $stmt1 = $con->prepare("SELECT productImage FROM products WHERE productId = ?");
                $stmt1->bind_param("i", $productId);
                $stmt1->execute();
                $result = $stmt1->get_result();
                while ($row = $result->fetch_assoc()) {
                    unlink(UPLOAD_PATH . $row['productImage']);
                }

                if ($stmt->execute()) {
                    $response['error'] = false;
                    $response['message'] = 'Product deleted successfully';
                } else {
                    $response['error'] = true;
                    $response['message'] = 'Some error occurred please try again';
                }
            }
            break;

        default:
            $response['error'] = true;
            $response['message'] = 'Invalid Operation Called';
    }
} else {
    $response['error'] = true;
    $response['message'] = 'Invalid API Call';
}

echo json_encode($response);

function isTheseParametersAvailable($params)
{
    foreach ($params as $param) {
        if (!isset($_POST[$param])) {
            return false;
        }
    }
    return true;
}

function compressImage($source, $destination, $quality)
{
    // Get image info 
    $imgInfo = getimagesize($source);
    $mime = $imgInfo['mime'];

    // Create a new image from file 
    switch ($mime) {
        case 'image/jpeg':
            $image = imagecreatefromjpeg($source);
            break;
        case 'image/png':
            $image = imagecreatefrompng($source);
            break;
        case 'image/gif':
            $image = imagecreatefromgif($source);
            break;
        default:
            $image = imagecreatefrompng($source);
    }

    // Save image 
    imagepng($image, $destination, $quality);
}
