<?php
header('Content-Type: application/json; charset=utf-8');
require_once 'db_connect.php';
define('UPLOAD_PATH', 'images/users/');
$response = array();

if (isset($_GET['apicall'])) {

    switch ($_GET['apicall']) {

        case 'signup':
            if (isTheseParametersAvailable(array('username', 'email', 'password'))) {
                $username = $_POST['username'];
                $email = $_POST['email'];
                $password = md5($_POST['password']);

                $stmt1 = $con->prepare("SELECT id FROM users WHERE username = ?");
                $stmt1->bind_param("s", $username);
                $stmt1->execute();
                $stmt1->store_result();

                $stmt2 = $con->prepare("SELECT id FROM users WHERE email = ?");
                $stmt2->bind_param("s", $email);
                $stmt2->execute();
                $stmt2->store_result();

                if ($stmt1->num_rows > 0) {
                    $response['errorCode'] = 1;
                    $response['error'] = true;
                    $response['message'] = '*This username is already taken';
                    $stmt1->close();
                } elseif ($stmt2->num_rows > 0) {
                    $response['errorCode'] = 2;
                    $response['error'] = true;
                    $response['message'] = '*This email address is already registered';
                    $stmt2->close();
                } else {
                    $stmt = $con->prepare("INSERT INTO users (username, email, password) VALUES (?, ?, ?)");
                    $stmt->bind_param("sss", $username, $email, $password);

                    if ($stmt->execute()) {
                        $stmt = $con->prepare("SELECT id, username, email, password FROM users WHERE username = ?");
                        $stmt->bind_param("s", $username);
                        $stmt->execute();
                        $stmt->bind_result($id, $username, $email, $password);
                        $stmt->fetch();

                        $user = array(
                            'id' => $id,
                            'username' => $username,
                            'email' => $email,
                            'password' => $password
                        );

                        $stmt->close();

                        $response['error'] = false;
                        $response['message'] = 'User registered successfully';
                        $response['user'] = $user;
                    }
                }
            } else {
                $response['errorCode'] = 3;
                $response['error'] = true;
                $response['message'] = 'required parameters are not available';
            }

            break;

        case 'loginusername':

            if (isTheseParametersAvailable(array('username', 'password'))) {
                $host = 'https://apex-admin.000webhostapp.com/';
                $username = $_POST['username'];
                $password = md5($_POST['password']);

                $stmt = $con->prepare("SELECT id, profilePicture, username, email, password, phoneNumber, gender, birthDate FROM users WHERE username = ? AND password = ?");
                $stmt->bind_param("ss", $username, $password);
                $stmt->bind_result($id, $profilePicture, $username, $email, $password, $phoneNumber, $gender, $birthDate);
                $stmt->execute();

                $stmt->store_result();

                if ($stmt->num_rows > 0) {
                    $stmt->fetch();
                    $user = array(
                        'id' => $id,
                        'profilePicture' => $host . UPLOAD_PATH . $profilePicture,
                        'username' => $username,
                        'email' => $email,
                        'password' => $password,
                        'phoneNumber' => $phoneNumber,
                        'gender' => $gender,
                        'birthDate' => $birthDate
                    );

                    $response['error'] = false;
                    $response['message'] = 'Login successfull';
                    $response['user'] = $user;
                } else {
                    $response['error'] = true;
                    $response['message'] = "Incorrect email or password";
                }
            } else {
                $response['error'] = true;
                $response['message'] = 'required parameters are not available';
            }
            break;

        case 'loginemail':

            if (isTheseParametersAvailable(array('email', 'password'))) {
                $host = 'https://apex-admin.000webhostapp.com/';
                $email = $_POST['email'];
                $password = md5($_POST['password']);

                $stmt = $con->prepare("SELECT id, profilePicture, username, email, password, phoneNumber, gender, birthDate FROM users WHERE email = ? AND password = ?");
                $stmt->bind_param("ss", $email, $password);
                $stmt->bind_result($id, $profilePicture, $username, $email, $password, $phoneNumber, $gender, $birthDate);
                $stmt->execute();

                $stmt->store_result();

                if ($stmt->num_rows > 0) {
                    $stmt->fetch();

                    $user = array(
                        'id' => $id,
                        'profilePicture' => $host . UPLOAD_PATH . $profilePicture,
                        'username' => $username,
                        'email' => $email,
                        'password' => $password,
                        'phoneNumber' => $phoneNumber,
                        'gender' => $gender,
                        'birthDate' => $birthDate
                    );

                    $response['error'] = false;
                    $response['message'] = 'Login successfull';
                    $response['user'] = $user;
                } else {
                    $response['error'] = true;
                    $response['message'] = "Incorrect email or password";
                }
            } else {
                $response['error'] = true;
                $response['message'] = 'required parameters are not available';
            }
            break;

        case 'loginadmin':

            if (isTheseParametersAvailable(array('email', 'password'))) {

                $email = $_POST['email'];
                $password = md5($_POST['password']);
                $category = "admin";

                $stmt = $con->prepare("SELECT id, username, email, password FROM users WHERE email = ? AND password = ? AND category = ?");
                $stmt->bind_param("sss", $email, $password, $category);
                $stmt->bind_result($id, $username, $email, $password);
                $stmt->execute();

                $stmt->store_result();

                if ($stmt->num_rows > 0) {

                    $users = array();
                    while ($stmt->fetch()) {
                        $temp = array();
                        $temp['id'] = $id;
                        $temp['username'] = $username;
                        $temp['email'] = $email;
                        $temp['password'] = $password;
                        array_push($users, $temp);
                    }
                    $response['users'] = $users;

                    $response['error'] = false;
                    $response['message'] = 'Login successfull';
                } else {
                    $response['error'] = true;
                    $response['message'] = "Incorrect email or password";
                }
            } else {
                $response['error'] = true;
                $response['message'] = 'required parameters are not available';
            }
            break;

        case 'createUser':
            if (isTheseParametersAvailable(array('username', 'email', 'password')) || isset($_POST['phoneNumber']) || isset($_POST['gender']) || isset($_POST['birthDate']) || isset($_FILES['profilePicture']['name'])) {
                $profilePicture = $_FILES['profilePicture']['name'];
                $username = $_POST['username'];
                $email = $_POST['email'];
                $password = md5($_POST['password']);
                $phoneNumber = $_POST['phoneNumber'];
                $gender = $_POST['gender'];
                $birthDate = $_POST['birthDate'];

                try {

                    if ($profilePicture == "") {
                        $stmt = $con->prepare("INSERT INTO users (username, email, password, phoneNumber, gender, birthDate) VALUES (?, ?, ?, ?, ?, ?)");
                        $stmt->bind_param("ssssss", $username, $email, $password, $phoneNumber, $gender, $birthDate);
                        if ($stmt->execute()) {
                            $response['error'] = false;
                            $response['message'] = 'User added successfully';
                        } else {
                            $response['error'] = true;
                            $response['message'] = $stmt->error;
                        }
                    } else {
                        compressImage($_FILES['profilePicture']['tmp_name'], UPLOAD_PATH . $profilePicture, 8);

                        $stmt = $con->prepare("INSERT INTO users (profilePicture, username, email, password, phoneNumber, gender, birthDate) VALUES (?, ?, ?, ?, ?, ?, ?)");
                        $stmt->bind_param("sssssss", $profilePicture, $username, $email, $password, $phoneNumber, $gender, $birthDate);
                        if ($stmt->execute()) {
                            $response['error'] = false;
                            $response['message'] = 'User added successfully';
                        } else {
                            $response['error'] = true;
                            $response['message'] = $stmt->error;
                        }
                    }
                } catch (Exception $e) {
                    $response['error'] = true;
                    $response['message'] = 'Something went wrong';
                }
            } else {
                $response['error'] = true;
                $response['message'] = 'Required parameters are not insufficient';
            }

            break;


        case 'readUser':
            $host = 'https://apex-admin.000webhostapp.com/';

            $stmt1 = $con->prepare("SELECT * FROM users");
            $stmt1->execute();
            $result = $stmt1->get_result()->fetch_all(MYSQLI_ASSOC);


            $stmt = $con->prepare("SELECT id, profilePicture, username, email, password, phoneNumber, gender, birthDate FROM users");
            $stmt->bind_result($id, $profilePicture, $username, $email, $password, $phoneNumber, $gender, $birthDate);

            if ($stmt->execute()) {

                $users = array();
                while ($stmt->fetch()) {
                    $temp = array();
                    $temp['id'] = $id;
                    $temp['profilePicture'] = $host . UPLOAD_PATH . $profilePicture;
                    $temp['username'] = $username;
                    $temp['email'] = $email;
                    $temp['password'] = $password;
                    $temp['phoneNumber'] = $phoneNumber;
                    $temp['gender'] = $gender;
                    $temp['birthDate'] = $birthDate;
                    array_push($users, $temp);
                }
                $response['users'] = $users;
            } else {
                $response['error'] = true;
                $response['message'] = $stmt->error;
            }

            break;

        case 'updateUser':
            if (isTheseParametersAvailable(array('id', 'username', 'email')) || isset($_POST['phoneNumber']) || isset($_POST['gender']) || isset($_POST['birthDate']) || isset($_FILES['profilePicture']['name'])) {
                $id = $_POST['id'];
                $profilePicture = $_FILES['profilePicture']['name'];
                $username = $_POST['username'];
                $email = $_POST['email'];
                $phoneNumber = $_POST['phoneNumber'];
                $gender = $_POST['gender'];
                $birthDate = $_POST['birthDate'];

                if (!$profilePicture == "") {
                    $stmt1 = $con->prepare("SELECT profilePicture FROM users WHERE id = ?");
                    $stmt1->bind_param("i", $id);
                    $stmt1->execute();
                    $result = $stmt1->get_result();
                    while ($row = $result->fetch_assoc()) {
                        if ($row == "" || $row == NULL) {
                            unlink(UPLOAD_PATH . $row['profilePicture']);
                        }
                    }
                    compressImage($_FILES['profilePicture']['tmp_name'], UPLOAD_PATH . $profilePicture, 8);

                    $stmt = $con->prepare("UPDATE users SET profilePicture = ?, username = ?, email = ?, phoneNumber = ?, gender = ?, birthDate = ? WHERE id = ?");
                    $stmt->bind_param("ssssssi", $profilePicture, $username, $email, $phoneNumber, $gender, $birthDate, $id);
                } else {
                    $stmt = $con->prepare("UPDATE users SET username = ?, email = ?, phoneNumber = ?, gender = ?, birthDate = ? WHERE id = ?");
                    $stmt->bind_param("sssssi", $username, $email, $phoneNumber, $gender, $birthDate, $id);
                }

                if ($stmt->execute()) {
                    $response['error'] = false;
                    $response['message'] = 'User updated successfully';
                } else {
                    $response['error'] = true;
                    $response['message'] = $stmt->error;
                }
            } else {
                $response['error'] = true;
                $response['message'] = 'required parameters are not insufficient';
            }


            break;

        case 'readUpdatedUser':
            if (isTheseParametersAvailable(array('id'))) {
                $host = 'https://apex-admin.000webhostapp.com/';

                $id = $_POST['id'];

                $stmt = $con->prepare("SELECT id, profilePicture, username, email, password, phoneNumber, gender, birthDate FROM users WHERE id = ?");
                $stmt->bind_param("i", $id);
                $stmt->bind_result($id, $profilePicture, $username, $email, $password, $phoneNumber, $gender, $birthDate);
                if ($stmt->execute()) {
                    $stmt->fetch();
                    $user = array(
                        'id' => $id,
                        'profilePicture' => $host . UPLOAD_PATH . $profilePicture,
                        'username' => $username,
                        'email' => $email,
                        'password' => $password,
                        'phoneNumber' => $phoneNumber,
                        'gender' => $gender,
                        'birthDate' => $birthDate
                    );

                    $response['error'] = false;
                    $response['message'] = 'Read successfull';
                    $response['user'] = $user;
                } else {
                    $response['error'] = true;
                    $response['message'] = $stmt->error;
                }
            } else {
                $response['error'] = true;
                $response['message'] = 'required parameters are not insufficient';
            }

            break;

        case 'deleteUser':
            if (isTheseParametersAvailable(array('id'))) {
                $id = $_POST['id'];

                $stmt = $con->prepare("DELETE FROM users WHERE id = ?");
                $stmt->bind_param("i", $id);

                $stmt1 = $con->prepare("SELECT profilePicture FROM users WHERE id = ?");
                $stmt1->bind_param("i", $id);
                $stmt1->execute();
                $result = $stmt1->get_result();
                while ($row = $result->fetch_assoc()) {
                    unlink(UPLOAD_PATH . $row['profilePicture']);
                }

                if ($stmt->execute()) {
                    $response['error'] = false;
                    $response['message'] = 'User deleted successfully';
                } else {
                    $response['error'] = true;
                    $response['message'] = 'Some error occurred please try again';
                }
            } else {
                $response['error'] = true;
                $response['message'] = 'required parameters are not insufficient';
            }
            break;


        default:
            $response['error'] = true;
            $response['message'] = 'Invalid Operation Called';
    }
} else {
    $response['error'] = true;
    $response['message'] = 'Invalid API Call';
}

echo json_encode($response);

function isTheseParametersAvailable($params)
{

    foreach ($params as $param) {
        if (!isset($_POST[$param])) {
            return false;
        }
    }
    return true;
}
function compressImage($source, $destination, $quality)
{
    // Get image info 
    $imgInfo = getimagesize($source);
    $mime = $imgInfo['mime'];

    // Create a new image from file 
    switch ($mime) {
        case 'image/jpeg':
            $image = imagecreatefromjpeg($source);
            break;
        case 'image/png':
            $image = imagecreatefrompng($source);
            break;
        case 'image/gif':
            $image = imagecreatefromgif($source);
            break;
        default:
            $image = imagecreatefrompng($source);
    }

    // Save image 
    imagepng($image, $destination, $quality);
}
