        <?php
        require_once 'db_connect.php';

        $response = array();
        define('UPLOAD_PATH', 'images/users/');
        if (isset($_GET['apicall'])) {

            switch ($_GET['apicall']) {

                case 'createTransaction':
                    if (isTheseParametersAvailable(array('invoiceNumber', 'transactionStatus', 'transactionAmount', 'transactionAddress', 'invoiceDate', 'paymentDate', 'userId', 'products'))) {
                        $invoiceNumber = $_POST['invoiceNumber'];
                        $transactionStatus = $_POST['transactionStatus'];
                        $transactionAmount = $_POST['transactionAmount'];
                        $transactionAddress = $_POST['transactionAddress'];
                        $invoiceDate = $_POST['invoiceDate'];
                        $paymentDate = $_POST['paymentDate'];
                        $userId = $_POST['userId'];
                        $products = $_POST['products'];

                        try {
                            $stmt = $con->prepare("INSERT INTO transactions (invoiceNumber, transactionStatus, transactionAmount, transactionAddress, invoiceDate, paymentDate, userId, products) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
                            $stmt->bind_param("ssdsssis", $invoiceNumber, $transactionStatus, $transactionAmount, $transactionAddress, $invoiceDate, $paymentDate, $userId, $products);

                            if (!$stmt->execute()) {
                                $response['error'] = true;
                                $response['message'] = $stmt->error;

                            } else {
                                $response['error'] = false;
                                $response['message'] = 'Transaction created successfully';
                                $response['lastId'] = $stmt->insert_id;
                            }
                        } catch (Exception $e) {
                            $response['error'] = true;
                            $response['message'] = $e;
                        }
                    } else {
                        $response['error'] = true;
                        $response['message'] = 'Required parameters are not insufficient';
                    }

                    break;

                case 'readTransaction':
                    if (isTheseParametersAvailable(array('userId'))) {
                        $getUserId = $_POST['userId'];

                        $stmt1 = $con->prepare("SELECT * FROM products");
                        $stmt1->execute();
                        $result = $stmt1->get_result()->fetch_all(MYSQLI_ASSOC);

                        if (!$result) {
                            $response['error'] = false;
                            $response['message'] = 'Table is empty';
                            $stmt1->close();
                        } else {
                            $stmt = $con->prepare("SELECT transactionId, invoiceNumber, transactionStatus, transactionAmount, transactionAddress, invoiceDate, paymentDate, userId, products FROM transactions WHERE userId = ?");
                            $stmt->bind_param("i", $getUserId);
                            $stmt->bind_result($transactionId, $invoiceNumber, $transactionStatus, $transactionAmount, $transactionAddress, $invoiceDate, $paymentDate, $userId, $products);

                            if ($stmt->execute()) {

                                $transactions = array();
                                while ($stmt->fetch()) {
                                    $temp = array();
                                    $temp['transactionId'] = $transactionId;
                                    $temp['invoiceNumber'] = $invoiceNumber;
                                    $temp['transactionStatus'] = $transactionStatus;
                                    $temp['transactionAmount'] = $transactionAmount;
                                    $temp['transactionAddress'] = $transactionAddress;
                                    $temp['invoiceDate'] = $invoiceDate;
                                    $temp['paymentDate'] = $paymentDate;
                                    $temp['userId'] = $userId;
                                    $temp['products'] = $products;
                                    array_push($transactions, $temp);
                                }
                                $response['transactions'] = $transactions;
                                $rowcount = $stmt->num_rows();
                                $response['count'] = $rowcount;
                            }
                        }
                    } else {
                        $response['error'] = true;
                        $response['message'] = 'Required parameters are not insufficient';
                    }

                    break;

                case 'readAllTransaction':
                    $host = 'https://apex-admin.000webhostapp.com/';
                    $queryResult = mysqli_query($con, "SELECT transactions.transactionId, transactions.invoiceNumber, transactions.transactionStatus , transactions.transactionAmount ,transactions.transactionAddress ,transactions.invoiceDate, transactions.paymentDate, users.profilePicture, users.username, transactions.userId, transactions.products
                    FROM transactions
                    LEFT JOIN users ON transactions.userId = users.id");



                    $transactions = array();
                    while ($row = mysqli_fetch_assoc($queryResult)) {
                        $temp = array();
                        $temp['transactionId'] = $row["transactionId"];
                        $temp['invoiceNumber'] = $row["invoiceNumber"];
                        $temp['transactionStatus'] = $row["transactionStatus"];
                        $temp['transactionAmount'] = $row["transactionAmount"];
                        $temp['transactionAddress'] = $row["transactionAddress"];
                        $temp['invoiceDate'] = $row["invoiceDate"];
                        $temp['paymentDate'] = $row["paymentDate"];
                        $temp['userId'] = $row["userId"];
                        $temp['username'] = $row["username"];
                        $temp['profilePicture'] = $host . UPLOAD_PATH . $row["profilePicture"];
                        $temp['products'] = $row["products"];
                        array_push($transactions, $temp);
                    }
                    $response['transactions'] = $transactions;



                    break;

                case 'updateTransaction':
                    if (isTheseParametersAvailable(array('transactionId', 'invoiceNumber', 'transactionStatus', 'transactionAmount', 'transactionAddress', 'invoiceDate',  'paymentDate', 'userId', 'products'))) {
                        $transactionId = $_POST['transactionId'];
                        $invoiceNumber = $_POST['invoiceNumber'];
                        $transactionStatus = $_POST['transactionStatus'];
                        $transactionAmount = $_POST['transactionAmount'];
                        $transactionAddress = $_POST['transactionAddress'];
                        $invoiceDate = $_POST['invoiceDate'];
                        $paymentDate = $_POST['paymentDate'];
                        $userId = $_POST['userId'];
                        $products = $_POST['products'];


                        $stmt = $con->prepare("UPDATE transactions SET invoiceNumber = ?, transactionStatus = ?, transactionAmount = ?, transactionAddress = ?, invoiceDate = ?, paymentDate = ? , userId = ?, products = ? WHERE transactionId = ?");
                        $stmt->bind_param("ssdsssisi", $invoiceNumber, $transactionStatus, $transactionAmount, $transactionAddress, $invoiceDate, $paymentDate, $userId, $products, $transactionId);

                        if ($stmt->execute()) {
                            $response['error'] = false;
                            $response['message'] = 'Transaction updated successfully';
                        } else {
                            $response['error'] = true;
                            $response['message'] = $stmt->error;
                        }
                    } else {
                        $response['error'] = true;
                        $response['message'] = 'required parameters are not insufficient';
                    }

                    break;

                case 'deleteTransaction':
                    if (isTheseParametersAvailable(array('transactionId'))) {
                        $transactionId = $_POST['transactionId'];

                        $stmt = $con->prepare("DELETE FROM transactions WHERE transactionId = ?");
                        $stmt->bind_param("i", $transactionId);

                        if ($stmt->execute()) {
                            $response['error'] = false;
                            $response['message'] = 'Transaction deleted successfully';
                        } else {
                            $response['error'] = true;
                            $response['message'] = $stmt->error;
                        }
                    } else {
                        $response['error'] = true;
                        $response['message'] = 'required parameters are not insufficient';
                    }
                    break;

                case 'updateNewTransaction':
                    if (isTheseParametersAvailable(array('transactionId', 'transactionStatus', 'paymentDate'))) {
                        $transactionId = $_POST['transactionId'];
                        $transactionStatus = $_POST['transactionStatus'];
                        $paymentDate = $_POST['paymentDate'];

                        $stmt = $con->prepare("UPDATE transactions SET transactionStatus = ?, paymentDate = ? WHERE transactionId = ?");
                        $stmt->bind_param("ssi", $transactionStatus, $paymentDate, $transactionId);

                        if ($stmt->execute()) {
                            $response['error'] = false;
                            $response['message'] = 'Payment Successful';
                        } else {
                            $response['error'] = true;
                            $response['message'] = $stmt->error;
                        }
                    } else {
                        $response['error'] = true;
                        $response['message'] = 'required parameters are not insufficient';
                    }

                    break;

                default:
                    $response['error'] = true;
                    $response['message'] = 'Invalid Operation Called';
            }
        } else {
            $response['error'] = true;
            $response['message'] = 'Invalid API Call';
        }

        echo json_encode($response);

        function isTheseParametersAvailable($params)
        {
            foreach ($params as $param) {
                if (!isset($_POST[$param])) {
                    return false;
                }
            }
            return true;
        }
